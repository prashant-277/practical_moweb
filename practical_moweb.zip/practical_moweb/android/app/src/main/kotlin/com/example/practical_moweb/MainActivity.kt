package com.example.practical_moweb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
