import 'package:get_storage/get_storage.dart';

const String baseUrl = "http://3.208.241.167:4000";
const String no_Internet = "No Internet Connection";

//main screen
const String getDataUrl = "/home_screen_list_grocery?app_uuid=d714957eb4675cf3";
const String postDataUrl = "/get_sub_category";

//storage
GetStorage storage = GetStorage();

